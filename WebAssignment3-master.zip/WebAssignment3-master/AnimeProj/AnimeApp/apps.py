from django.apps import AppConfig


class AnimeappConfig(AppConfig):
    name = 'AnimeApp'



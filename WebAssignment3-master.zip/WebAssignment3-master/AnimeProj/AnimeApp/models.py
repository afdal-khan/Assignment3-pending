from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
#from django.views.generic import UpdateView

# Create your models here.
# from AppName.AppFolder import Classname
from AnimeApp.animeModels import Anime

class Item